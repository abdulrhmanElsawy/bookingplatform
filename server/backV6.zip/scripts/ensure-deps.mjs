import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import {
  ensureSharedLink,
  linkPath,
  sharedDist,
  sharedPkg,
  sharedRoot,
  sharedSiblingReady,
  sharedLinkReady,
} from './shared-link.mjs';

function run(cmd, cwd) {
  console.info(`[ensure-deps] ${cmd} (in ${cwd})`);
  const result = spawnSync(cmd, {
    cwd,
    stdio: 'inherit',
    shell: true,
  });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

if (!existsSync(sharedPkg)) {
  console.error(
    '[ensure-deps] Missing ../shared/package.json — deploy shared/ next to server/.',
  );
  process.exit(1);
}

if (!existsSync(resolve(sharedRoot, 'node_modules'))) {
  run('npm install --include=dev', sharedRoot);
}

run('npm install --include=dev', serverRoot);

try {
  ensureSharedLink();
} catch (err) {
  console.error('[ensure-deps]', err instanceof Error ? err.message : err);
  process.exit(1);
}

if (!existsSync(sharedDist)) {
  run('npm run build', sharedRoot);
}

if (!sharedSiblingReady()) {
  console.error(
    '[ensure-deps] shared/dist is missing after build.\n' +
      '  cd shared && npm install --include=dev && npm run build',
  );
  process.exit(1);
}

if (!sharedLinkReady() && !(existsSync(linkPath) && sharedSiblingReady())) {
  console.error('[ensure-deps] Could not link @growth-world/shared into node_modules.');
  process.exit(1);
}
