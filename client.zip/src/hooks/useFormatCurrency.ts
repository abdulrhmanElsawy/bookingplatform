import { useCallback } from 'react';

import { useCurrencyStore } from '../store/currencyStore';
import { formatCurrency } from '../utils/formatters';
import { useLanguage } from './useLanguage';

/**
 * Subscribes to the active display currency so price labels re-render after switching.
 */
export function useFormatCurrency() {
  const currency = useCurrencyStore((s) => s.currency);
  const { currentLang } = useLanguage();

  return useCallback(
    (amount: number) => formatCurrency(amount, currentLang, currency),
    [currency, currentLang],
  );
}
