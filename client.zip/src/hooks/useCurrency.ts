import { useCallback } from 'react';

import {
  type AppCurrency,
  SUPPORTED_CURRENCIES,
} from '../config/currencies';
import type { AppLang } from './useLanguage';
import { useLanguage } from './useLanguage';
import { syncCurrencyPreference } from '../services/userPreferenceSync';
import { useAuthStore } from '../store/authStore';
import { useCurrencyStore } from '../store/currencyStore';

export type { AppCurrency };

export function currencyDisplayName(code: AppCurrency, lang: AppLang): string {
  try {
    const dn = new Intl.DisplayNames(lang === 'ar' ? 'ar-SA' : 'en', {
      type: 'currency',
    });
    return dn.of(code) ?? code;
  } catch {
    return code;
  }
}

export function currencyNarrowSymbol(code: AppCurrency, lang: AppLang): string {
  const parts = new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-US', {
    style: 'currency',
    currency: code,
    currencyDisplay: 'narrowSymbol',
  }).formatToParts(1);
  const symbol = parts.find((p) => p.type === 'currency')?.value;
  return symbol ?? code;
}

export function useCurrency() {
  const currency = useCurrencyStore((s) => s.currency);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const user = useAuthStore((s) => s.user);
  const setSession = useAuthStore((s) => s.setSession);
  const { currentLang } = useLanguage();

  const switchCurrency = useCallback(
    async (next: AppCurrency) => {
      useCurrencyStore.getState().setCurrency(next);

      if (user) {
        const prefs = user.preferences ?? {
          language: currentLang,
          currency: next,
          notifications: { email: true, inApp: true },
        };
        setSession({
          ...user,
          preferences: { ...prefs, currency: next },
        });
      }

      if (isAuthenticated) {
        await syncCurrencyPreference(next);
      }
    },
    [currentLang, isAuthenticated, setSession, user],
  );

  return {
    currency,
    switchCurrency,
    supportedCurrencies: SUPPORTED_CURRENCIES,
    currencyDisplayName: (code: AppCurrency) => currencyDisplayName(code, currentLang),
    currencyNarrowSymbol: (code: AppCurrency) => currencyNarrowSymbol(code, currentLang),
  };
}
