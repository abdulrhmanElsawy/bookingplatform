import { create } from 'zustand';

import {
  type AppCurrency,
  DEFAULT_CURRENCY,
  normalizeAppCurrency,
  readStoredCurrency,
  writeStoredCurrency,
} from '../config/currencies';

interface CurrencyState {
  currency: AppCurrency;
  setCurrency: (currency: AppCurrency) => void;
  hydrateFromPreferences: (currency: string | undefined) => void;
}

export const useCurrencyStore = create<CurrencyState>((set) => ({
  currency: readStoredCurrency(),

  setCurrency: (currency) => {
    writeStoredCurrency(currency);
    set({ currency });
  },

  hydrateFromPreferences: (currency) => {
    const next = currency ? normalizeAppCurrency(currency) : readStoredCurrency();
    writeStoredCurrency(next);
    set({ currency: next });
  },
}));

export function getActiveCurrency(): AppCurrency {
  return useCurrencyStore.getState().currency ?? DEFAULT_CURRENCY;
}
