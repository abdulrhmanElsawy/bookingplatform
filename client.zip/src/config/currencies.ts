/** ISO 4217 codes supported in the UI currency switcher. */
export const SUPPORTED_CURRENCIES = [
  'SAR',
  'USD',
  'EUR',
  'AED',
  'KWD',
  'BHD',
  'OMR',
  'QAR',
  'EGP',
] as const;

export type AppCurrency = (typeof SUPPORTED_CURRENCIES)[number];

export const DEFAULT_CURRENCY: AppCurrency = 'SAR';

const STORAGE_KEY = 'gw_currency';

/** Static SAR conversion (display approximation; listing prices are stored in SAR). */
export const SAR_CONVERSION_RATE: Record<AppCurrency, number> = {
  SAR: 1,
  USD: 0.2667,
  EUR: 0.246,
  AED: 0.979,
  KWD: 0.0818,
  BHD: 0.1003,
  OMR: 0.1025,
  QAR: 0.9704,
  EGP: 13.05,
};

export function isAppCurrency(value: string): value is AppCurrency {
  return (SUPPORTED_CURRENCIES as readonly string[]).includes(value);
}

export function normalizeAppCurrency(value: string | undefined | null): AppCurrency {
  if (value && isAppCurrency(value)) {
    return value;
  }
  return DEFAULT_CURRENCY;
}

export function readStoredCurrency(): AppCurrency {
  if (typeof localStorage === 'undefined') {
    return DEFAULT_CURRENCY;
  }
  return normalizeAppCurrency(localStorage.getItem(STORAGE_KEY));
}

export function writeStoredCurrency(currency: AppCurrency): void {
  if (typeof localStorage === 'undefined') {
    return;
  }
  localStorage.setItem(STORAGE_KEY, currency);
}

export function convertAmountFromSar(amountSar: number, target: AppCurrency): number {
  return amountSar * SAR_CONVERSION_RATE[target];
}
