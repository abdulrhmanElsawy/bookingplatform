import { ChevronDown } from 'lucide-react';
import { useId, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { type AppCurrency } from '../../config/currencies';
import { useCurrency } from '../../hooks/useCurrency';
import styles from './Header.module.css';

type CurrencySwitcherProps = {
  className?: string;
  onSelected?: () => void;
};

export function CurrencySwitcher({ className, onSelected }: CurrencySwitcherProps) {
  const { t } = useTranslation('common');
  const {
    currency,
    switchCurrency,
    supportedCurrencies,
    currencyDisplayName,
    currencyNarrowSymbol,
  } = useCurrency();
  const [open, setOpen] = useState(false);
  const listId = useId();

  async function select(next: AppCurrency) {
    await switchCurrency(next);
    setOpen(false);
    onSelected?.();
  }

  return (
    <div className={`${styles.currencySwitcher} ${className ?? ''}`.trim()}>
      <button
        type="button"
        className={`${styles.drawerLink} ${styles.currencyTrigger}`}
        aria-expanded={open}
        aria-controls={listId}
        onClick={() => setOpen((v) => !v)}
        data-testid="currency-switcher-trigger"
      >
        <span className={styles.currencyTriggerLabel}>
          <span className={styles.currencyTriggerTitle}>{t('currency')}</span>
          <span className={styles.currencyTriggerValue}>
            {currencyNarrowSymbol(currency)} · {currency}
          </span>
        </span>
        <ChevronDown
          size={18}
          className={`${styles.currencyChevron} ${open ? styles.currencyChevronOpen : ''}`}
          aria-hidden
        />
      </button>
      {open ? (
        <div
          id={listId}
          className={styles.currencyMenu}
          role="listbox"
          aria-label={t('currency')}
          data-testid="currency-switcher-menu"
        >
          {supportedCurrencies.map((code) => {
            const active = code === currency;
            return (
              <button
                key={code}
                type="button"
                role="option"
                aria-selected={active}
                className={`${styles.currencyOption} ${active ? styles.currencyOptionActive : ''}`}
                onClick={() => void select(code)}
                data-testid={`currency-option-${code}`}
              >
                <span className={styles.currencyOptionCode}>{code}</span>
                <span className={styles.currencyOptionName}>{currencyDisplayName(code)}</span>
              </button>
            );
          })}
          <p className={styles.currencyHint}>{t('currencyConversionHint')}</p>
        </div>
      ) : null}
    </div>
  );
}
