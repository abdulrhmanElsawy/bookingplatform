export { GuestSavingsStrip } from './GuestSavingsStrip';
